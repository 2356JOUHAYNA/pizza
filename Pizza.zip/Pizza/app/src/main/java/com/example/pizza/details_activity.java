package com.example.pizza;

import android.os.Bundle;
import android.text.Html;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class details_activity extends AppCompatActivity {


    private TextView textViewDescription;
    private TextView textViewIngredients;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);


        textViewDescription = findViewById(R.id.textViewDescription);
        textViewIngredients = findViewById(R.id.textViewIngredients);


        String description = getIntent().getStringExtra("description");
        String detailingReg = getIntent().getStringExtra("detaisingreg");


        textViewDescription.setText(Html.fromHtml("<b><i>Description:</i></b><br>" + description));
        textViewIngredients.setText(Html.fromHtml("<b><i>Ingredients:</i></b><br>" + detailingReg));
    }

}
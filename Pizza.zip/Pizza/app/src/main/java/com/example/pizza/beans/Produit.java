package com.example.pizza.beans;

public class Produit {


    private int id;
    private String nom;
    private int nbingrediants;
    private int photo;

    private String duree;
    private String detaisingreg;
    private String description;
    private String preparation;
    private int comp;



    private static int nbr;

    public Produit(String nom, int nbingrediants, int photo, String duree, String detaisingreg, String description, String preparation) {
        this.id = nbr++;
        this.nom = nom;
        this.nbingrediants = nbingrediants;
        this.photo = photo;
        this.duree = duree;
        this.detaisingreg = detaisingreg;
        this.description = description;
        this.preparation = preparation;

    }

    public Produit() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPhoto() {
        return photo;
    }

    public void setPhoto(int photo) {
        this.photo = photo;
    }

    public int getNbingrediants() {
        return nbingrediants;
    }

    public void setNbingrediants(int nbingrediants) {
        this.nbingrediants = nbingrediants;
    }

    public int getComp() {
        return comp;
    }

    public void setComp(int comp) {
        this.comp = comp;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getDetaisingreg() {
        return detaisingreg;
    }

    public void setDetaisingreg(String detaisingreg) {
        this.detaisingreg = detaisingreg;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPreparation() {
        return preparation;
    }

    public void setPreparation(String preparation) {
        this.preparation = preparation;
    }

    public String getDuree() {
        return duree;
    }

    public void setDuree(String duree) {
        this.duree = duree;
    }

    public static int getNbr() {
        return nbr;
    }

    public static void setNbr(int nbr) {
        Produit.nbr = nbr;
    }

    @Override
    public String toString() {
        return "Produit{" +
                "id=" + id +
                ", photo=" + photo +
                ", nbingrediants=" + nbingrediants +
                ", comp=" + comp +
                ", nom='" + nom + '\'' +
                ", detaisingreg='" + detaisingreg + '\'' +
                ", description='" + description + '\'' +
                ", preparation='" + preparation + '\'' +
                ", duree=" + duree +
                '}';
    }
}
